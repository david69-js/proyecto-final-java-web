package com.example.paginaWebUniversidad;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class PaginaWebUniversidadApplication {

	public static void main(String[] args) {
		SpringApplication.run(PaginaWebUniversidadApplication.class, args);
	}

}
