package com.example.paginaWebUniversidad.Controller;

import com.example.paginaWebUniversidad.Model.Curso;
import com.example.paginaWebUniversidad.Model.Task;

import com.example.paginaWebUniversidad.Repository.CursoRepository;
import com.example.paginaWebUniversidad.Repository.TodoRepository;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RestController;

import java.util.List;
import java.util.logging.Logger;

@RestController
public class Controller {
    @Autowired
    private TodoRepository todoRepository;
    @Autowired
    private CursoRepository cursoRepository;

    @GetMapping("/")
    public String Hello(){
        return "Hllo";
    }

    @GetMapping("/tasks")
    public List<Task> getTasks(){
        return todoRepository.findAll();
    }
    @PostMapping(value = "savaTaks")
    public String SaveTask(@RequestBody Task task){
        todoRepository.save(task);
        return "Saved Task";
    }
    private static final org.slf4j.Logger logger = LoggerFactory.getLogger(Controller.class);

    @PostMapping(value = "/saveCurso")
    public String saveCurso(@RequestBody Curso curso) {
        cursoRepository.save(curso);
        return "Saved Curso";
    }

}
