package com.example.paginaWebUniversidad.Model;

import jakarta.persistence.*;

@Entity
@Table(schema = "CursoCrud")
public class Curso {
    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)

    private long id;
    @Column
    private String nombre_curso;
    @Column
    private String descripcion;

    public void setId(long id) {
        this.id = id;
    }

    public long getId() {
        return id;
    }

    public String getDescription() {
        return descripcion;
    }

    public void setDescription(String descripcion) {
        this.descripcion = descripcion;
    }

    public void setNombre_curso(String nombre_curso) {
        this.nombre_curso = nombre_curso;
    }

    public String getNombre_curso() {
        return nombre_curso;
    }
}
