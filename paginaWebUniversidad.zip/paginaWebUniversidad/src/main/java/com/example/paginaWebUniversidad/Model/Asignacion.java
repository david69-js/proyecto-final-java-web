package com.example.paginaWebUniversidad.Model;

public class Asignacion {
}
