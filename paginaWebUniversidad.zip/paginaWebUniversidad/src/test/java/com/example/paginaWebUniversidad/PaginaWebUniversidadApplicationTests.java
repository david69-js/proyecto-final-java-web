package com.example.paginaWebUniversidad;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class PaginaWebUniversidadApplicationTests {

	@Test
	void contextLoads() {
	}

}
